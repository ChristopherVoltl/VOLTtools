﻿public static class SimManager
{
    public static SimRobot Robot;
    public static RobotModel RobotModel;
}
