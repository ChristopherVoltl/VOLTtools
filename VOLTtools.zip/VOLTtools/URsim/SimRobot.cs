﻿using System;
using System.Collections.Generic;
using Rhino;
using Rhino.Geometry;

public class SimRobot
{
    private readonly RobotModel _model;
    private readonly Dictionary<string, Guid> _linkMeshIds = new Dictionary<string, Guid>();
    private readonly Dictionary<string, Transform> _visualOffsets = new Dictionary<string, Transform>();

    public SimRobot(RobotModel model)
    {
        _model = model;

        // Initialize mesh instances
        foreach (var link in _model.Links)
        {
            string linkName = link.Key;
            var visual = link.Value.Visual;
            if (visual?.Geometry?.Size == null) continue;

            string path = FKEngine.ResolveMeshPath(visual.Geometry.Size);
            var original = MeshCache.Get(path);
            if (original == null) continue;

            var mesh = original.DuplicateMesh();

            // Apply visual offset once and cache it
            var visualXform = FKEngine.BuildTransform(visual.Origin);
            mesh.Transform(visualXform);
            _visualOffsets[linkName] = visualXform;

            // Add to Rhino doc
            var id = RhinoDoc.ActiveDoc.Objects.AddMesh(mesh);
            _linkMeshIds[linkName] = id;
        }
    }

    public void Update(Dictionary<string, Transform> fkTransforms)
    {
        foreach (var kvp in _linkMeshIds)
        {
            string linkName = kvp.Key;
            Guid objId = kvp.Value;

            if (!fkTransforms.TryGetValue(linkName, out Transform fk)) continue;

            // Update position using FK transform
            RhinoDoc.ActiveDoc.Objects.Transform(objId, fk, true);
        }

        RhinoDoc.ActiveDoc.Views.Redraw();
    }
}